import {Component} from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ApiService } from './shared/api.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title(title: any) {
    throw new Error('Method not implemented.');
  }
  closeResult = '';
  err: any;
  formValue!: FormGroup
  details:any;

  constructor(private modalService: NgbModal, private formBuilder:FormBuilder , private api:ApiService) {}

  ngOnInit(): void {

    this.formValue = this.formBuilder.group({
      firstname:[''],
      lastname: [''],
      email:[''],
      role: ['']

    })
     
  }


  open(content:any) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  postData(){
    this.api.postEmpolyee(this.formValue.value).subscribe((res:any)=>{
      alert('details added succefully')
      
    },err=>{
      alert("something going wrong")
    })
  }
 

  getData(){
    this.api.getEmployee().subscribe((res:any)=>{
      this.details=res;
    })
  }
}